// function to load subjects at runtime
function getModule() {
    var domain = document.getElementById("chooseDomain");
    var module = document.getElementById("chooseModule");
    var selectedDomain = domain.options[domain.selectedIndex].value


    console.log(domain, ' ', module, ' ', selectedDomain);
    if (selectedDomain == "JEE") {
        module.options.length = 0;
        module.options[0] = new Option("Select", "Select");
        module.options[1] = new Option("Core.Java", "CoreJava");
        module.options[2] = new Option("Servlet-JSP", "Servlet-JSP");
        module.options[3] = new Option("Spring", "Spring");
    }
    else if (selectedDomain == ".NET") {
        module.options.length = 0;
        module.options[0] = new Option("Select", "Select");
        module.options[1] = new Option("C#", "SP");
        module.options[2] = new Option("ADO.NET", "AdN");
        module.options[3] = new Option("ASP.NET", "AspN");
    }
    else {
        module.options.length = 0;
        module.options[0] = new Option("Select", "Select");
    }
}

function showDetails() {
    if (calcForm.checkValidity()) {
        var empnumber = document.calcForm.empNumber.value;
        var empname = document.calcForm.empName.value;
        var domain = document.calcForm.chooseDomain.value;
        var module = document.calcForm.chooseModule.value;
        var mpt = parseInt(MPT.value);
        var mtt = parseInt(MTT.value);
        var assignmentMrk = parseInt(assignMRK.value);
        var result = mpt + mtt + assignmentMrk;

        // document.getElementById("result").innerHTML = "score is " + result;

        //      alert("score is "+result);
        //     }
        // }
        var details ="Module Score Calculation..\n"
            + "\n  MPT marks is : " + mpt
            + "\n MTT Marks is : " + mtt
            + "\n Assignment Marks is : " + assignmentMrk
            + "\n Total Score is : " + result

            // answer for Section-1HTML&JS&BOOTSTRAP (7)
        alert(details);
    }
}


