//Answer for Section 2-ES6 (d)
//Creating Class Login with method getLogin()
class Login {
    getLogin() {
        return "getLogin() function of Login Class";
    }
    getLogOut() {
        return "getLogOut() function of Logout Class";
    }
}
//Creating Employee Class
class Employee {
    getLogin() {
        return "getLogin() function of Login Class";
    }
    getLogOut() {
        return "getLogout() function of Logout Class";
    }
    constructor(empId, empName, empSalary, empDesignation) {
        this._empId_ = empId;
        this._empName_ = empName;
        this._empSalary_ = empSalary;
        this._empDesignation_ = empDesignation;
    }
    get empId() {
        return this._empId_;
    }
    set empId(empId) {
        this._empId_ = empId;
    }
    get empName() {
        return this._empName_;
    }
    set empName(empName) {
        this._empName_ = empName;
    }
    get empSalary() {
        return this._empSalary_;
    }
    set empSalary(empSalary) {
        this._empSalary_ = empSalary;
    }
    get empDesignation() {
        return this._empDesignation_;
    }
    set empDesignation(empDesignation) {
        this._empDesignation_ = empDesignation;
    }
    printDetails() {
        let details = `Employee Details are
    Employee Id is ${this.empId}
    Employee Name is ${this.empName}
    Employee Salary is ${this.empSalary}
    Employee Designation is ${this.empDesignation}`;
        return details;
    }
} //End Of the Employee Class
class EmployeeUtility {
    //To initilize Employee Objects in th List
    constructor() {
        //Create List Of EmplsObject of Set type
        this.listOfEmplsObject = new Set();
        let empObj1 = new Employee(1002, 'Vikash', 9812, 'Consultant');
        let empObj2 = new Employee(1003, 'Amresh', 6661, 'Sr Consultant');
        let empObj3 = new Employee(1001, 'Uma', 10000, 'Sr Manager');
        let empObj4 = new Employee(1000, 'Vaishali', 9123, 'Manager');

        //Answer from Section 2-ES6 (a)

        //Adding employee objects in Set
        this.listOfEmplsObject.add(empObj1);
        this.listOfEmplsObject.add(empObj2);
        this.listOfEmplsObject.add(empObj3);
        this.listOfEmplsObject.add(empObj4);
    }
    //Answer from Section 2-ES6 (b)
    //sortByEmpId() function
    sortByEmpId() {
        console.log("After sorting in ascending" + " order by emp id");
        let sortedSet = Array.from(this.listOfEmplsObject).sort((e1, e2) => e1.empId - e2.empId);

        return sortedSet;


    }
    getAllEmployees() {
        return this.listOfEmplsObject;
    }
    //Answer from Section 2-ES6 (c)
    //Delete  Employee Object By empId
    deleteByEmpId(id) {
        let deletedEmployee = Array.from(this.listOfEmplsObject).find(e => e.empId === id);
        this.listOfEmplsObject.delete(deletedEmployee);


        return this.listOfEmplsObject;
    }
}//end of Employee Utility
//This Creates List and Add Employees to list
let UtilityObj;
//print all the employees
console.log('Menu:');
console.log('1- Add All Employees');
console.log('2- Show Employees');
console.log('3- Sort By Emp Id');
console.log('4- Delete By Id');
console.log('0- Exit');
let choiceYN = 'N';
do {
    let choice = parseInt(prompt('ur Choice:', 0));
    switch (choice) {
        //Employee List is Prepared
        case 1: {
            utilityObj = new EmployeeUtility();
            console.log('Employee list is prepared..!');
        }
            break;
        //show all Employees
        case 2: {
            let listOfEmpsObject = utilityObj.getAllEmployees();
            for (let emp of listOfEmpsObject) {
                console.log(emp.printDetails());
            }
        }
            break;
        //sort By empId
        case 3: {
            let sortedlistOfEmpsObject = utilityObj.sortByEmpId();
            for (let emp of sortedlistOfEmpsObject) {
                console.log(emp.printDetails());
            }
        }
            break;
        //delete By empId
        case 4: {
            console.log('Current List of Employees');
            let listOfEmpsObject = utilityObj.getAllEmployees();
            for (let emp of listOfEmpsObject) {
                console.log(emp.printDetails());
            }
            let id = parseInt(prompt('Employee Id:', 0));
            let result = confirm("Are you sure wants to delete..?");
            if (result) {
                //calling deleteByEmpId() function
                let newEmpListObj = utilityObj.deleteByEmpId(id);
                console.log("\nAfter deleting " + id);
                if (newEmpListObj != null) {
                    for (let emp of newEmpListObj) {
                        console.log(emp.printDetails());
                    }
                }
                else
                    console.log('Employee Id does not exist');
            }
        }
            break;
        case 0: {
            console.log("\n\n\tThank you..!");
            break;
        }
        default: {
            console.log("\n\n\tInvalid Choice..!");
        }
            break;
    }//end of switchcase

    choiceYN = prompt("Do you want to continue..?");
} while (choiceYN === 'Y' || choiceYN === 'y');

 //Answer from Section 2-ES6 (d)
//using create
let logObj = new Login();
let empObj = new Employee();
//inheritance using Object.create()
empObj = Object.create(logObj);
console.log("logObj.getLogin():" + logObj.getLogin());
console.log("empObj.getLogin():" + Employee.prototype.getLogin());
